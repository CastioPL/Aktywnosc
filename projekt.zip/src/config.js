require("dotenv").config()
 
module.exports = { 
    TOKEN: process.env.TOKEN
}